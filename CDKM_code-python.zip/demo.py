from CDKM import CDKM
from sklearn.cluster import KMeans
from sklearn.preprocessing import MinMaxScaler
import funs as Ifuns
import funs_metric as Mfuns
import numpy as np

name = "CACD_29v2_20200916"

X, y_true, N, dim, c_true = Ifuns.load_mat(f"data/{name}.mat")
X = X.astype(np.float64)


MM = MinMaxScaler(feature_range=(0, 1))
X = MM.fit_transform(X)

init_Y = Ifuns.initial_Y(X, c_true, rep=10, way="random")

mod = CDKM(X, c_true, debug=0)
mod.opt(init_Y, ITER=200)
Y = mod.y_pre
n_iter = mod.n_iter_

obj = Mfuns.multi_kmeans_obj(X, Y)
print(f"cdkm: mean = {np.mean(obj)}, std = {np.std(obj)}, min = {np.min(obj)}, iter = {np.mean(n_iter)}")

# paper
# Iris: random, mean = 6.9981, std = 0, min = 6.9981, iter = 3.52

# # Kmeans
# mod = KMeans(n_clusters=c_true, init="random").fit(X)
# y = mod.labels_
# n_iter = mod.n_iter_
# obj = Mfuns.kmeans_obj(X, y)
# print(f"kmeans: {obj}, iter = {n_iter}")
