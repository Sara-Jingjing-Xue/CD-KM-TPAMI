# A python implementation of "Coordinate Descent Method for $k$-means"

### install
```
python setup.py build_ext --inplace
```

### usage:
see demo.py
